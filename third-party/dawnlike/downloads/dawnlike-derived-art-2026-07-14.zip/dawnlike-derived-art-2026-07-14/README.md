# Modified Dawnlike art used by Auto-Battle Got Me Killed

This package contains 96 image files that the game modifies or recomposes from Dawnlike.
The files are released under CC BY-SA 3.0. See `LICENSE.txt` and `UPSTREAM_README.txt`.

Changes include recoloring, redrawing, additive ornaments, shape edits, frame extraction,
and recomposition into animation, wall, object, and UI sheets. `MANIFEST.csv` records the
project path, identified upstream source, change category, and SHA-256 for every file.

This license applies to the Dawnlike-derived artwork in this package. It does not apply to
the game's code, trademarks, original artwork, or unrelated third-party assets.

Package date: 2026-07-14
Upstream revision: `1b6bf5c265eaca6c253482d29fe01822c81fbba3`
Source: https://github.com/hadean-mirrors/dawnlike
License: https://creativecommons.org/licenses/by-sa/3.0/
